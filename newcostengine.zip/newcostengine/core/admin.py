from django.contrib import admin
from .models import *


class ProductInline(admin.TabularInline):
    model = AddItem

class ProductAdmin(admin.ModelAdmin):
    inlines = [
        ProductInline, 
    ]

admin.site.register(Product,ProductAdmin)
admin.site.register(Category)
admin.site.register(SubCategory)
admin.site.register(SubSubCategory)
admin.site.register(ProductOption)
admin.site.register(Region)
admin.site.site_header = "Admin Dashboard"
admin.site.site_title = "Admin Dashboard"
admin.site.index_title = "Welcome to Admin Dashboard"